export class Users {


      public fname: string;
      public lname: string;
      public email: string;
      public role: string;
      public mobile: string;
      public aboutme: string;
      public profile_pic:string;
      public oldpwd:string;
      public newpwd:string;
      public conpwd:string;


}

